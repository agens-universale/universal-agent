from __future__ import annotations

import logging
from dataclasses import dataclass

from mcp.server.fastmcp import FastMCP
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route

from .errors import OfficeReaderError
from .logging_config import mask_base64_in_args
from .reader import (
    read_document_from_bytes,
    read_file_from_disk,
)
from .security import validate_path

log = logging.getLogger(__name__)


@dataclass
class ServerConfig:
    allowed_dirs: list[str]
    allow_any: bool
    max_file_size: int
    max_output_chars: int
    timeout_s: int


def build_server(cfg: ServerConfig) -> FastMCP:
    mcp = FastMCP("mcp-office-reader")

    @mcp.tool(name="read_file")
    def read_file_tool(path: str) -> str:
        """Read an office document from the server's filesystem and return markdown.
        Use when the file is available at a filesystem path (e.g. via a shared volume).
        Supported: .pdf, .docx, .xls, .xlsx, .pptx, .csv, .html, .msg."""
        args = {"path": path}
        try:
            real = validate_path(path, cfg.allowed_dirs, allow_any=cfg.allow_any)
            result = read_file_from_disk(
                real,
                max_file_size=cfg.max_file_size,
                max_output_chars=cfg.max_output_chars,
                timeout_s=cfg.timeout_s,
            )
            log.info(
                "read_file ok",
                extra={
                    "event": "tool_call",
                    "tool": "read_file",
                    "tool_args": args,
                    "output_chars": len(result),
                },
            )
            return result
        except OfficeReaderError as e:
            log.warning(
                "read_file failed",
                extra={
                    "event": "tool_error",
                    "tool": "read_file",
                    "tool_args": args,
                    "error_category": e.category.value,
                },
            )
            raise

    @mcp.tool(name="read_document")
    def read_document_tool(filename: str, content_base64: str) -> str:
        """Read an office document provided as base64-encoded bytes.
        Use when the file is not available on the server's filesystem.
        Supported: .pdf, .docx, .xls, .xlsx, .pptx, .csv, .html, .msg."""
        args = mask_base64_in_args(
            {"filename": filename, "content_base64": content_base64}
        )
        try:
            result = read_document_from_bytes(
                filename=filename,
                content_base64=content_base64,
                max_file_size=cfg.max_file_size,
                max_output_chars=cfg.max_output_chars,
                timeout_s=cfg.timeout_s,
            )
            log.info(
                "read_document ok",
                extra={
                    "event": "tool_call",
                    "tool": "read_document",
                    "tool_args": args,
                    "output_chars": len(result),
                },
            )
            return result
        except OfficeReaderError as e:
            log.warning(
                "read_document failed",
                extra={
                    "event": "tool_error",
                    "tool": "read_document",
                    "tool_args": args,
                    "error_category": e.category.value,
                },
            )
            raise

    return mcp


def build_asgi_app(cfg: ServerConfig) -> Starlette:
    mcp = build_server(cfg)
    inner = mcp.streamable_http_app()

    async def health(_request):
        return JSONResponse({"status": "ok"})

    return Starlette(
        routes=[
            Route("/health", health, methods=["GET"]),
            Mount("/", app=inner),
        ],
        lifespan=inner.router.lifespan_context,
    )
