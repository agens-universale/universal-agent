from __future__ import annotations

from enum import Enum
from typing import Any

SUPPORTED_FORMATS_LIST = ".pdf, .docx, .xls, .xlsx, .pptx, .csv, .html, .msg"
LEGACY_HINT_EXTS = frozenset({".doc", ".ppt", ".odt", ".ods", ".odp", ".rtf"})


class ErrorCategory(str, Enum):
    FILE_NOT_FOUND = "file_not_found"
    PATH_NOT_ALLOWED = "path_not_allowed"
    UNSUPPORTED_FORMAT = "unsupported_format"
    FILE_TOO_LARGE = "file_too_large"
    PARSE_FAILED = "parse_failed"
    TIMEOUT = "timeout"
    INVALID_BASE64 = "invalid_base64"
    PERMISSION_DENIED = "permission_denied"


class OfficeReaderError(Exception):
    """Base exception carrying an ErrorCategory and render context."""

    def __init__(self, category: ErrorCategory, **context: Any) -> None:
        self.category = category
        self.context = context
        super().__init__(format_error(category, **context))


def format_error(category: ErrorCategory, **ctx: Any) -> str:
    match category:
        case ErrorCategory.FILE_NOT_FOUND:
            return f"Error: file not found: {ctx['path']}. Check that the path is correct."
        case ErrorCategory.PATH_NOT_ALLOWED:
            dirs = ", ".join(ctx["allowed_dirs"])
            return (
                f"Error: path not allowed: {ctx['path']}. "
                f"Server reads only from: {dirs}."
            )
        case ErrorCategory.UNSUPPORTED_FORMAT:
            base = (
                f"Error: unsupported format '{ctx['ext']}'. "
                f"Supported: {SUPPORTED_FORMATS_LIST}."
            )
            if ctx["ext"].lower() in LEGACY_HINT_EXTS:
                return (
                    base
                    + " Convert to a modern format first "
                    "(e.g. .docx / .xlsx / .pptx)."
                )
            return base
        case ErrorCategory.FILE_TOO_LARGE:
            return (
                f"Error: file too large: {ctx['size_mb']}MB "
                f"(max {ctx['max_mb']}MB)."
            )
        case ErrorCategory.PARSE_FAILED:
            return (
                f"Error: failed to parse {ctx['path']} as {ctx['fmt']}. "
                f"File may be corrupted or password-protected."
            )
        case ErrorCategory.TIMEOUT:
            return (
                f"Error: processing timed out after {ctx['timeout_s']}s. "
                f"File may be too complex."
            )
        case ErrorCategory.INVALID_BASE64:
            return "Error: content_base64 is not valid base64."
        case ErrorCategory.PERMISSION_DENIED:
            return f"Error: permission denied reading {ctx['path']}."
