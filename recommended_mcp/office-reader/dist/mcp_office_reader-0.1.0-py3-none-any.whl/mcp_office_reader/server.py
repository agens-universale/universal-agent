from __future__ import annotations

import logging
from dataclasses import dataclass, field

from mcp.server.fastmcp import FastMCP
from pydantic import ValidationError
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Mount, Route

from .errors import ErrorCategory, OfficeReaderError
from .logging_config import mask_base64_in_args
from .reader import (
    read_document_from_bytes,
    read_file_from_disk,
)
from .security import validate_path
from .writer import generate_docx, generate_xlsx
from .writer_io import encode_base64_checked, write_bytes_checked
from .writer_schema import WorkbookSpec

log = logging.getLogger(__name__)


def _validate_workbook(raw: dict) -> WorkbookSpec:
    try:
        return WorkbookSpec.model_validate(raw)
    except ValidationError as ve:
        # pydantic errors are verbose; pick the first one for the user message
        first = ve.errors()[0]
        loc = ".".join(str(x) for x in first["loc"])
        raise OfficeReaderError(
            ErrorCategory.INVALID_INPUT,
            reason=f"{loc}: {first['msg']}",
        ) from ve


@dataclass
class ServerConfig:
    allowed_dirs: list[str]
    allow_any: bool
    max_file_size: int
    max_output_chars: int
    timeout_s: int
    max_output_base64_size: int = 20 * 1024 * 1024
    output_allowed_dirs: list[str] = field(default_factory=list)


def build_server(cfg: ServerConfig) -> FastMCP:
    mcp = FastMCP("mcp-office-reader")

    @mcp.tool(name="read_file")
    def read_file_tool(path: str) -> str:
        """Read an office document from the server's filesystem and return markdown.
        Use when the file is available at a filesystem path (e.g. via a shared volume).
        Supported: .pdf, .doc, .docx, .xls, .xlsx, .pptx, .csv, .html, .msg."""
        args = {"path": path}
        try:
            real = validate_path(path, cfg.allowed_dirs, allow_any=cfg.allow_any)
            result = read_file_from_disk(
                real,
                max_file_size=cfg.max_file_size,
                max_output_chars=cfg.max_output_chars,
                timeout_s=cfg.timeout_s,
            )
            log.info(
                "read_file ok",
                extra={
                    "event": "tool_call",
                    "tool": "read_file",
                    "tool_args": args,
                    "output_chars": len(result),
                },
            )
            return result
        except OfficeReaderError as e:
            log.warning(
                "read_file failed",
                extra={
                    "event": "tool_error",
                    "tool": "read_file",
                    "tool_args": args,
                    "error_category": e.category.value,
                },
            )
            raise

    @mcp.tool(name="read_document")
    def read_document_tool(filename: str, content_base64: str) -> str:
        """Read an office document provided as base64-encoded bytes.
        Use when the file is not available on the server's filesystem.
        Supported: .pdf, .doc, .docx, .xls, .xlsx, .pptx, .csv, .html, .msg."""
        args = mask_base64_in_args(
            {"filename": filename, "content_base64": content_base64}
        )
        try:
            result = read_document_from_bytes(
                filename=filename,
                content_base64=content_base64,
                max_file_size=cfg.max_file_size,
                max_output_chars=cfg.max_output_chars,
                timeout_s=cfg.timeout_s,
            )
            log.info(
                "read_document ok",
                extra={
                    "event": "tool_call",
                    "tool": "read_document",
                    "tool_args": args,
                    "output_chars": len(result),
                },
            )
            return result
        except OfficeReaderError as e:
            log.warning(
                "read_document failed",
                extra={
                    "event": "tool_error",
                    "tool": "read_document",
                    "tool_args": args,
                    "error_category": e.category.value,
                },
            )
            raise

    @mcp.tool(name="create_docx_file")
    def create_docx_file_tool(
        path: str, markdown: str, overwrite: bool = False
    ) -> dict:
        """Generate a .docx file from markdown and write it to the server filesystem.
        Use when the caller has filesystem access to the server (e.g. via a shared volume).
        Markdown supports headings, paragraphs, inline bold/italic/code/links, bulleted
        and numbered lists (nestable), GFM tables, blockquotes, fenced code blocks,
        horizontal rules. No images in this version.
        Writes only to paths under --output-allowed-dirs (default: same as --allowed-dirs).
        Fails with file_exists if the target already exists and overwrite=False."""
        args = {
            "path": path,
            "overwrite": overwrite,
            "markdown_chars": len(markdown),
        }
        try:
            data = generate_docx(markdown)
            n = write_bytes_checked(
                path, data,
                output_allowed_dirs=cfg.output_allowed_dirs,
                allow_any=cfg.allow_any,
                overwrite=overwrite,
            )
            log.info(
                "create_docx_file ok",
                extra={
                    "event": "tool_call",
                    "tool": "create_docx_file",
                    "tool_args": args,
                    "bytes_written": n,
                },
            )
            return {"path": path, "bytes_written": n}
        except OfficeReaderError as e:
            log.warning(
                "create_docx_file failed",
                extra={
                    "event": "tool_error",
                    "tool": "create_docx_file",
                    "tool_args": args,
                    "error_category": e.category.value,
                },
            )
            raise

    @mcp.tool(name="create_docx")
    def create_docx_tool(filename: str, markdown: str) -> dict:
        """Generate a .docx file from markdown and return its content as base64.
        Use when the caller does not have filesystem access to the server (e.g. agent
        chat attaching the result). Size-capped by --max-output-base64-size.
        Markdown supports headings, paragraphs, inline bold/italic/code/links, bulleted
        and numbered lists (nestable), GFM tables, blockquotes, fenced code blocks,
        horizontal rules. No images in this version."""
        args = {"filename": filename, "markdown_chars": len(markdown)}
        try:
            data = generate_docx(markdown)
            enc = encode_base64_checked(
                data, max_base64_bytes=cfg.max_output_base64_size
            )
            log.info(
                "create_docx ok",
                extra={
                    "event": "tool_call",
                    "tool": "create_docx",
                    "tool_args": args,
                    "raw_bytes": enc["raw_bytes"],
                },
            )
            return {"filename": filename, **enc}
        except OfficeReaderError as e:
            log.warning(
                "create_docx failed",
                extra={
                    "event": "tool_error",
                    "tool": "create_docx",
                    "tool_args": args,
                    "error_category": e.category.value,
                },
            )
            raise

    @mcp.tool(name="create_xlsx_file")
    def create_xlsx_file_tool(
        path: str, workbook: dict, overwrite: bool = False
    ) -> dict:
        """Generate an .xlsx file from a structured workbook spec and write it to disk.
        Use when the caller has filesystem access to the server (e.g. via a shared volume).
        workbook shape: {sheets: [{name, columns: [{name, type, format?, width?}],
        rows: [[...]], freeze_header?, auto_filter?, merges?, cell_styles?}, ...]}.
        Types: text, number, integer, date, datetime, bool, currency, percent.
        Dates as ISO-8601 strings. No formulas.
        Ranges in `merges` and `cell_styles` use A1-notation anchored to the final grid:
        row 1 is the auto-generated bold header, data starts at row 2.
        Writes only to paths under --output-allowed-dirs (default: same as --allowed-dirs).
        Fails with file_exists if the target already exists and overwrite=False.
        See README section "Создание документов" for the full schema."""
        sheet_count = len(workbook.get("sheets", [])) if isinstance(workbook, dict) else 0
        args = {
            "path": path,
            "overwrite": overwrite,
            "sheet_count": sheet_count,
        }
        try:
            spec = _validate_workbook(workbook)
            data = generate_xlsx(spec)
            n = write_bytes_checked(
                path, data,
                output_allowed_dirs=cfg.output_allowed_dirs,
                allow_any=cfg.allow_any,
                overwrite=overwrite,
            )
            log.info(
                "create_xlsx_file ok",
                extra={
                    "event": "tool_call",
                    "tool": "create_xlsx_file",
                    "tool_args": args,
                    "bytes_written": n,
                },
            )
            return {"path": path, "bytes_written": n}
        except OfficeReaderError as e:
            log.warning(
                "create_xlsx_file failed",
                extra={
                    "event": "tool_error",
                    "tool": "create_xlsx_file",
                    "tool_args": args,
                    "error_category": e.category.value,
                },
            )
            raise

    @mcp.tool(name="create_xlsx")
    def create_xlsx_tool(filename: str, workbook: dict) -> dict:
        """Generate an .xlsx file from a structured workbook spec and return its content as base64.
        Use when the caller does not have filesystem access to the server (e.g. agent
        chat attaching the result). Size-capped by --max-output-base64-size.
        workbook shape: {sheets: [{name, columns: [{name, type, format?, width?}],
        rows: [[...]], freeze_header?, auto_filter?, merges?, cell_styles?}, ...]}.
        Types: text, number, integer, date, datetime, bool, currency, percent.
        Dates as ISO-8601 strings. No formulas.
        Ranges in `merges` and `cell_styles` use A1-notation anchored to the final grid:
        row 1 is the auto-generated bold header, data starts at row 2.
        See README section "Создание документов" for the full schema."""
        sheet_count = len(workbook.get("sheets", [])) if isinstance(workbook, dict) else 0
        args = {"filename": filename, "sheet_count": sheet_count}
        try:
            spec = _validate_workbook(workbook)
            data = generate_xlsx(spec)
            enc = encode_base64_checked(
                data, max_base64_bytes=cfg.max_output_base64_size
            )
            log.info(
                "create_xlsx ok",
                extra={
                    "event": "tool_call",
                    "tool": "create_xlsx",
                    "tool_args": args,
                    "raw_bytes": enc["raw_bytes"],
                },
            )
            return {"filename": filename, **enc}
        except OfficeReaderError as e:
            log.warning(
                "create_xlsx failed",
                extra={
                    "event": "tool_error",
                    "tool": "create_xlsx",
                    "tool_args": args,
                    "error_category": e.category.value,
                },
            )
            raise

    return mcp


def build_asgi_app(cfg: ServerConfig) -> Starlette:
    mcp = build_server(cfg)
    inner = mcp.streamable_http_app()

    async def health(_request):
        return JSONResponse({"status": "ok"})

    return Starlette(
        routes=[
            Route("/health", health, methods=["GET"]),
            Mount("/", app=inner),
        ],
        lifespan=inner.router.lifespan_context,
    )
